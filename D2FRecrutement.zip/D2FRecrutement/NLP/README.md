# Deep learning test

## Problème

Développer un modèle capable d'identifier le locuteur (Chirac vs. Mitterrand) d'un segment de discours politique.

## Data

Les données sont au format Pickle

Les `sequences` sont la version preprocessed des `sentences`. Le dictionnaire produit lors de la tokenization est fourni.
