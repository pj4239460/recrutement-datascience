# Classification problem

## Problem

Prédire la légitimité d'une transaction

## Data

Un dataset de transactions anonymisées labélisées comme frauduleuses ou innocentes