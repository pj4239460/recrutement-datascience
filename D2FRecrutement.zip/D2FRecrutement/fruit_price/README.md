# Classification problem

## Problem

Prédire le prix de vente de lots d'un fruit

## Data

Un dataset contenat des enregistrements de vente d'un fruit